
package snake;

import java.awt.event.KeyEvent;


public class movimiento extends Serpent{
    
    switch(evento.getKeyCode()){
               
                
            case KeyEvent.VK_LEFT:
            moverIzquierda();
                break;
                
            case KeyEvent.VK_RIGHT:
            moverDerecha();
                break;
            
            default:
                System.out.println("Tecla no reconocida");
        }
}
